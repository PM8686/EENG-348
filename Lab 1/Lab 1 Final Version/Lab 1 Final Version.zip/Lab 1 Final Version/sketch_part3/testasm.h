unsigned int fib(unsigned char a, unsigned char b);

