unsigned int testasm (unsigned char, unsigned char);

